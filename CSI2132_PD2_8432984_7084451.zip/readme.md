# Hotel Database Manager

Project designed for uOttawa CSI2132 Databases I course, to match specifications in assignment document.